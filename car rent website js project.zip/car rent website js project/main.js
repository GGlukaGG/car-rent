const STEP_API_Cars = "https://rentcar.stepprojects.ge/api/Car/popular";
const carsContainer = document.getElementById("carsContainer");

const fuelIcon = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22V8a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v14"/><path d="M3 14h14"/><path d="M17 8h2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><path d="M7 6V3"/><path d="M11 6V3"/></svg>`;
const transmissionIcon = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="6" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="12" cy="18" r="2"/><path d="M5 8v8"/><path d="M12 8v2"/><path d="M19 8v2a5 5 0 0 1-5 5h-2"/></svg>`;
const capacityIcon = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`;
const heartIcon = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`;
const noCarSvg = `<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><rect x="1" y="3" width="15" height="13" rx="2"/><path d="m16 8 4 4v4h-4"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>`;

// ── Header login state ────────────────────────────────────────────────────────
const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
document.getElementById("loggedIn").style.display = isLoggedIn ? "flex" : "none";
document.getElementById("loggedOut").style.display = isLoggedIn ? "none" : "flex";

document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("userPhone");
    localStorage.removeItem("token");
    window.location.reload();
});

// ── Theme ─────────────────────────────────────────────────────────────────────
const savedTheme = localStorage.getItem("theme") || "light";
document.documentElement.setAttribute("data-theme", savedTheme);

function applyThemeLabel(theme) {
    const label = theme === "dark" ? "☀️ თემა" : "🌙 თემა";
    ["themeBtn", "themeBtnIn"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = label;
    });
}
applyThemeLabel(savedTheme);

["themeBtn", "themeBtnIn"].forEach(id => {
    document.getElementById(id)?.addEventListener("click", () => {
        const next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
        document.documentElement.setAttribute("data-theme", next);
        localStorage.setItem("theme", next);
        applyThemeLabel(next);
    });
});

// ── Favorite ──────────────────────────────────────────────────────────────────
function saveFavorite(carId) {
    const phone = localStorage.getItem("userPhone");
    if (!phone || !carId) return;
    fetch("https://rentcar.stepprojects.ge/api/Users/" + encodeURIComponent(phone) + "/favorites/" + carId, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
    })
    .then(res => console.log("Favorite saved, status:", res.status))
    .catch(err => console.error("Favorite error:", err));
}

// ── Image helpers ─────────────────────────────────────────────────────────────
function getRawImages(car) {
    return [car.imageUrl1, car.imageUrl2, car.imageUrl3, car.image1, car.image2, car.image3]
        .filter(url => url && url.trim() !== "");
}
function testImage(url) {
    return new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve(url);
        img.onerror = () => resolve(null);
        img.src = url;
    });
}
async function getValidImages(car) {
    const results = await Promise.all(getRawImages(car).map(testImage));
    return results.filter(Boolean);
}

// ── Carousel ──────────────────────────────────────────────────────────────────
function buildCarousel(wrap, validImages) {
    if (validImages.length === 0) {
        wrap.classList.add("no-image");
        wrap.innerHTML = noCarSvg;
        return;
    }
    let current = 0;
    const imgEls = validImages.map((src, i) => {
        const img = document.createElement("img");
        img.src = src;
        img.alt = "";
        img.style.opacity = i === 0 ? "1" : "0";
        img.style.zIndex = i === 0 ? "1" : "0";
        wrap.appendChild(img);
        return img;
    });
    if (validImages.length > 1) {
        const dotsWrap = document.createElement("div");
        dotsWrap.className = "carousel-dots";
        const dots = validImages.map((_, i) => {
            const dot = document.createElement("div");
            dot.className = "carousel-dot" + (i === 0 ? " active" : "");
            dotsWrap.appendChild(dot);
            return dot;
        });
        wrap.appendChild(dotsWrap);
        wrap.addEventListener("click", () => {
            imgEls[current].style.opacity = "0";
            imgEls[current].style.zIndex = "0";
            dots[current].classList.remove("active");
            current = (current + 1) % validImages.length;
            imgEls[current].style.opacity = "1";
            imgEls[current].style.zIndex = "1";
            dots[current].classList.add("active");
        });
    }
}

// ── Build card ────────────────────────────────────────────────────────────────
function buildCard(car, images) {
    const city = car.city || "";
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
        <div class="card-header">
            <div>
                <div class="card-title">${car.brand} ${car.model}</div>
                <div class="card-subtitle">${city}${city && car.year ? " / " : ""}${car.year || ""}</div>
            </div>
            <button class="favorite-btn">${heartIcon}</button>
        </div>
        <div class="card-image-wrap"></div>
        <div class="card-specs">
            ${car.fuelCapacity ? `<div class="spec-item">${fuelIcon} ${car.fuelCapacity}ლ</div>` : ""}
            ${car.transmission ? `<div class="spec-item">${transmissionIcon} ${car.transmission}</div>` : ""}
            ${car.capacity     ? `<div class="spec-item">${capacityIcon} ${car.capacity}კაცი</div>` : ""}
        </div>
        <div class="card-footer">
            <div class="card-price">${car.price}₾<span>/დღიური</span></div>
            <button class="rent-btn" onclick="location.href='rent.html?id=${car.id}'">იქირავე</button>
        </div>
    `;
    buildCarousel(card.querySelector(".card-image-wrap"), images);
    card.querySelector(".favorite-btn").addEventListener("click", function(e) {
        e.stopPropagation();
        this.classList.toggle("active");
        const svg = this.querySelector("svg");
        const isActive = this.classList.contains("active");
        svg.setAttribute("fill", isActive ? "#e74c3c" : "none");
        svg.setAttribute("stroke", isActive ? "#e74c3c" : "currentColor");
        if (isActive) saveFavorite(car.id);
    });
    return card;
}

// ── Popular cars ──────────────────────────────────────────────────────────────
async function fetchCars() {
    carsContainer.innerHTML = "<p>იტვირთება...</p>";
    try {
        const response = await fetch(STEP_API_Cars);
        if (!response.ok) throw new Error("HTTP error: " + response.status);
        const cars = await response.json();
        const validCars = cars
            .filter(car => car.brand && car.model && car.price)
            .sort(() => Math.random() - 0.5)
            .slice(0, 4);
        const carsWithImages = await Promise.all(
            validCars.map(async car => ({ car, images: await getValidImages(car) }))
        );
        carsContainer.innerHTML = "";
        const title = document.createElement("p");
        title.className = "section-title";
        title.textContent = "პოპულარული მანქანები";
        carsContainer.before(title);
        carsWithImages.forEach(({ car, images }) => carsContainer.appendChild(buildCard(car, images)));
    } catch (error) {
        carsContainer.innerHTML = `<p>შეცდომა: ${error.message}</p>`;
    }
}
fetchCars();

// ── All Cars ──────────────────────────────────────────────────────────────────
const allCarsContainer = document.getElementById("allCarsContainer");

async function fetchAllCars() {
    allCarsContainer.innerHTML = "<p>იტვირთება...</p>";
    try {
        const response = await fetch("https://rentcar.stepprojects.ge/api/Car");
        if (!response.ok) throw new Error("HTTP error: " + response.status);
        const cars = await response.json();
        const validCars = cars.filter(car => car.brand && car.model && car.price);
        const carsWithImages = await Promise.all(
            validCars.map(async car => ({ car, images: await getValidImages(car) }))
        );
        allCarsContainer.innerHTML = "";
        const title = document.createElement("p");
        title.className = "section-title";
        title.textContent = "ყველა მანქანა";
        allCarsContainer.before(title);
        carsWithImages.forEach(({ car, images }) => allCarsContainer.appendChild(buildCard(car, images)));
    } catch (error) {
        allCarsContainer.innerHTML = `<p>შეცდომა: ${error.message}</p>`;
    }
}
fetchAllCars();