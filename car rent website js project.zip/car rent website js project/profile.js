// ── Theme ──────────────────────────────────────────────────────────────────
const t = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', t);

const phone = localStorage.getItem('userPhone');
if (!phone) { window.location.href = 'login.html'; }

const BASE = 'https://rentcar.stepprojects.ge';

const fuelIcon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22V8a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v14"/><path d="M3 14h14"/><path d="M17 8h2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><path d="M7 6V3"/><path d="M11 6V3"/></svg>';
const transmissionIcon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="6" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="12" cy="18" r="2"/><path d="M5 8v8"/><path d="M12 8v2"/><path d="M19 8v2a5 5 0 0 1-5 5h-2"/></svg>';
const capacityIcon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';
const heartIcon = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
const noCarSvg = '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><rect x="1" y="3" width="15" height="13" rx="2"/><path d="m16 8 4 4v4h-4"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>';

// ── Image helpers ──────────────────────────────────────────────────────────
function getRawImages(car) {
    return [car.imageUrl1, car.imageUrl2, car.imageUrl3, car.image1, car.image2, car.image3]
        .filter(url => url && url.trim() !== '');
}
function testImage(url) {
    return new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve(url);
        img.onerror = () => resolve(null);
        img.src = url;
    });
}
async function getValidImages(car) {
    const results = await Promise.all(getRawImages(car).map(testImage));
    return results.filter(Boolean);
}

// ── Carousel ───────────────────────────────────────────────────────────────
function buildCarousel(wrap, validImages) {
    if (validImages.length === 0) {
        wrap.classList.add('no-image');
        wrap.innerHTML = noCarSvg;
        return;
    }
    let current = 0;
    const imgEls = validImages.map((src, i) => {
        const img = document.createElement('img');
        img.src = src; img.alt = '';
        img.style.opacity = i === 0 ? '1' : '0';
        img.style.zIndex = i === 0 ? '1' : '0';
        wrap.appendChild(img);
        return img;
    });
    if (validImages.length > 1) {
        const dotsWrap = document.createElement('div');
        dotsWrap.className = 'carousel-dots';
        const dots = validImages.map((_, i) => {
            const dot = document.createElement('div');
            dot.className = 'carousel-dot' + (i === 0 ? ' active' : '');
            dotsWrap.appendChild(dot);
            return dot;
        });
        wrap.appendChild(dotsWrap);
        wrap.addEventListener('click', () => {
            imgEls[current].style.opacity = '0'; imgEls[current].style.zIndex = '0';
            dots[current].classList.remove('active');
            current = (current + 1) % validImages.length;
            imgEls[current].style.opacity = '1'; imgEls[current].style.zIndex = '1';
            dots[current].classList.add('active');
        });
    }
}

// ── Render full card ───────────────────────────────────────────────────────
async function renderFullCard(container, car) {
    const images = await getValidImages(car);
    const city = car.city || '';
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML =
        '<div class="card-header">' +
            '<div>' +
                '<div class="card-title">' + (car.brand || '') + ' ' + (car.model || '') + '</div>' +
                '<div class="card-subtitle">' + city + (city && car.year ? ' / ' : '') + (car.year || '') + '</div>' +
            '</div>' +
            '<button class="favorite-btn active">' + heartIcon + '</button>' +
        '</div>' +
        '<div class="card-image-wrap"></div>' +
        '<div class="card-specs">' +
            (car.fuelCapacity ? '<div class="spec-item">' + fuelIcon + ' ' + car.fuelCapacity + 'ლ</div>' : '') +
            (car.transmission ? '<div class="spec-item">' + transmissionIcon + ' ' + car.transmission + '</div>' : '') +
            (car.capacity     ? '<div class="spec-item">' + capacityIcon + ' ' + car.capacity + 'კაცი</div>' : '') +
        '</div>' +
        '<div class="card-footer">' +
            '<div class="card-price">' + (car.price || '') + '\u20be<span>/დღიური</span></div>' +
            '<button class="rent-btn" onclick="location.href=\'rent.html?id=' + car.id + '\'">იქირავე</button>' +
        '</div>';

    const svg = card.querySelector('.favorite-btn svg');
    svg.setAttribute('fill', '#e74c3c');
    svg.setAttribute('stroke', '#e74c3c');

    buildCarousel(card.querySelector('.card-image-wrap'), images);
    container.appendChild(card);
}

// ── Load user info ─────────────────────────────────────────────────────────
async function loadUser() {
    try {
        const res = await fetch(BASE + '/api/Users/' + encodeURIComponent(phone));
        const user = await res.json();
        document.getElementById('profileName').textContent = (user.firstName || '') + ' ' + (user.lastName || '');
        document.getElementById('profilePhone').textContent = phone;
        const initials = ((user.firstName?.[0] || '') + (user.lastName?.[0] || '')).toUpperCase();
        document.getElementById('avatar').textContent = initials;
    } catch {
        document.getElementById('profileName').textContent = phone;
    }
}

// ── Load rented cars ───────────────────────────────────────────────────────
async function loadRented() {
    const container = document.getElementById('rentedCars');
    try {
        const res = await fetch(BASE + '/Purchase/' + encodeURIComponent(phone));
        const text = await res.text();
        if (!text || text.includes('No products')) {
            container.innerHTML = '<p class="empty-msg">ნაქირავები მანქანები არ გაქვთ</p>';
            return;
        }
        const purchases = JSON.parse(text);
        console.log('Purchase data:', purchases); // ← shows exact field names
        if (!Array.isArray(purchases) || purchases.length === 0) {
            container.innerHTML = '<p class="empty-msg">ნაქირავები მანქანები არ გაქვთ</p>';
            return;
        }
        purchases.forEach(p => {
            console.log('Single purchase object:', p); // ← shows all fields

            // Try every possible field name
            const brand = p.carBrand || '';
            const model = p.carModel || '';
            const name = (brand + ' ' + model).trim() || 'უცნობი მანქანა';
            const city = p.city || '-';
            const days = p.multiplier || '-';
            const total = p.pricePaid || '-';
            const id = p.carId || '';

            const card = document.createElement('div');
            card.className = 'rental-card';
            card.innerHTML =
                '<div class="rental-card-title">' + name +
                    '<span class="rental-badge">' + id + '</span>' +
                '</div>' +
                '<div class="rental-row"><span>ქალაქი:</span><span>' + city + '</span></div>' +
                '<div class="rental-row"><span>დღეით</span><span>' + days + ' დღეით</span></div>' +
                '<div class="rental-row"><span>გადახდილია:</span><span>' + total + ' ლარი</span></div>';
            container.appendChild(card);
        });
    } catch(err) {
        console.error('Purchase error:', err);
        container.innerHTML = '<p class="empty-msg">ნაქირავები მანქანები არ გაქვთ</p>';
    }
}

// ── Load posted cars ───────────────────────────────────────────────────────
async function loadPosted() {
    const container = document.getElementById('postedCars');
    try {
        const res = await fetch(BASE + '/api/Car/byPhone?PhoneNumber=' + encodeURIComponent(phone));
        if (!res.ok) { container.innerHTML = '<p class="empty-msg">განცხადებები არ გაქვთ</p>'; return; }
        const cars = await res.json();
        if (!cars || cars.length === 0) { container.innerHTML = '<p class="empty-msg">განცხადებები არ გაქვთ</p>'; return; }
        for (const car of cars) await renderFullCard(container, car);
    } catch {
        container.innerHTML = '<p class="empty-msg">განცხადებები არ გაქვთ</p>';
    }
}

// ── Load liked cars ────────────────────────────────────────────────────────
async function loadLiked() {
    const container = document.getElementById('likedCars');
    try {
        const res = await fetch(BASE + '/api/Users/' + encodeURIComponent(phone) + '/favorite-cars');
        if (!res.ok) { container.innerHTML = '<p class="empty-msg">მოწონებული მანქანები არ გაქვთ</p>'; return; }
        const data = await res.json();
        if (!data || data.length === 0) { container.innerHTML = '<p class="empty-msg">მოწონებული მანქანები არ გაქვთ</p>'; return; }
        for (const item of data) {
            const car = item.car || item;
            await renderFullCard(container, car);
        }
    } catch(err) {
        console.error('Liked cars error:', err);
        container.innerHTML = '<p class="empty-msg">მოწონებული მანქანები არ გაქვთ</p>';
    }
}

loadUser();
loadRented();
loadPosted();
loadLiked();