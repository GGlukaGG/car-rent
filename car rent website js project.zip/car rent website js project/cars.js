// ── Theme ──────────────────────────────────────────────────────────────────
const t = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', t);

// ── Icons ───────────────────────────────────────────────────────────────────
const fuelIcon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22V8a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v14"/><path d="M3 14h14"/><path d="M17 8h2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><path d="M7 6V3"/><path d="M11 6V3"/></svg>';
const transmissionIcon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="6" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="12" cy="18" r="2"/><path d="M5 8v8"/><path d="M12 8v2"/><path d="M19 8v2a5 5 0 0 1-5 5h-2"/></svg>';
const capacityIcon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';
const heartIcon = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
const noCarSvg = '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5"><rect x="1" y="3" width="15" height="13" rx="2"/><path d="m16 8 4 4v4h-4"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>';

const carsGrid = document.getElementById('carsGrid');
let allCars = [];

// ── Favorite ──────────────────────────────────────────────────────────────────
function saveFavorite(carId) {
    const phone = localStorage.getItem('userPhone');
    if (!phone || !carId) return;
    fetch('https://rentcar.stepprojects.ge/api/Users/' + encodeURIComponent(phone) + '/favorites/' + carId, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    })
    .then(res => console.log('Favorite saved, status:', res.status))
    .catch(err => console.error('Favorite error:', err));
}

// ── Image helpers ────────────────────────────────────────────────────────────
function getRawImages(car) {
    return [car.imageUrl1, car.imageUrl2, car.imageUrl3, car.image1, car.image2, car.image3]
        .filter(url => url && url.trim() !== '');
}
function testImage(url) {
    return new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve(url);
        img.onerror = () => resolve(null);
        img.src = url;
    });
}
async function getValidImages(car) {
    const results = await Promise.all(getRawImages(car).map(testImage));
    return results.filter(Boolean);
}

// ── Carousel ─────────────────────────────────────────────────────────────────
function buildCarousel(wrap, validImages) {
    if (validImages.length === 0) {
        wrap.classList.add('no-image');
        wrap.innerHTML = noCarSvg;
        return;
    }
    let current = 0;
    const imgEls = validImages.map((src, i) => {
        const img = document.createElement('img');
        img.src = src; img.alt = '';
        img.style.opacity = i === 0 ? '1' : '0';
        img.style.zIndex = i === 0 ? '1' : '0';
        wrap.appendChild(img);
        return img;
    });
    if (validImages.length > 1) {
        const dotsWrap = document.createElement('div');
        dotsWrap.className = 'carousel-dots';
        const dots = validImages.map((_, i) => {
            const dot = document.createElement('div');
            dot.className = 'carousel-dot' + (i === 0 ? ' active' : '');
            dotsWrap.appendChild(dot);
            return dot;
        });
        wrap.appendChild(dotsWrap);
        wrap.addEventListener('click', () => {
            imgEls[current].style.opacity = '0'; imgEls[current].style.zIndex = '0';
            dots[current].classList.remove('active');
            current = (current + 1) % validImages.length;
            imgEls[current].style.opacity = '1'; imgEls[current].style.zIndex = '1';
            dots[current].classList.add('active');
        });
    }
}

// ── Render cards ─────────────────────────────────────────────────────────────
function renderCards(carsWithImages) {
    carsGrid.innerHTML = '';
    if (carsWithImages.length === 0) {
        carsGrid.innerHTML = '<p class="empty-msg">მანქანები ვერ მოიძებნა</p>';
        return;
    }
    carsWithImages.forEach(({ car, images }) => {
        const city = car.city || '';
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML =
            '<div class="card-header">' +
                '<div>' +
                    '<div class="card-title">' + car.brand + ' ' + car.model + '</div>' +
                    '<div class="card-subtitle">' + city + (city && car.year ? ' / ' : '') + (car.year || '') + '</div>' +
                '</div>' +
                '<button class="favorite-btn">' + heartIcon + '</button>' +
            '</div>' +
            '<div class="card-image-wrap"></div>' +
            '<div class="card-specs">' +
                (car.fuelCapacity ? '<div class="spec-item">' + fuelIcon + ' ' + car.fuelCapacity + 'ლ</div>' : '') +
                (car.transmission ? '<div class="spec-item">' + transmissionIcon + ' ' + car.transmission + '</div>' : '') +
                (car.capacity     ? '<div class="spec-item">' + capacityIcon + ' ' + car.capacity + 'კაცი</div>' : '') +
            '</div>' +
            '<div class="card-footer">' +
                '<div class="card-price">' + car.price + '\u20be<span>/დღიური</span></div>' +
                '<button class="rent-btn" onclick="location.href=\'rent.html?id='+car.id+'\'">იქირავე</button>' +
            '</div>';

        buildCarousel(card.querySelector('.card-image-wrap'), images);
        card.querySelector('.favorite-btn').addEventListener('click', function(e) {
            e.stopPropagation();
            this.classList.toggle('active');
            const svg = this.querySelector('svg');
            const isActive = this.classList.contains('active');
            svg.setAttribute('fill', isActive ? '#e74c3c' : 'none');
            svg.setAttribute('stroke', isActive ? '#e74c3c' : 'currentColor');
            if (isActive) saveFavorite(car.id);
        });
        carsGrid.appendChild(card);
    });
}

// ── Filter ────────────────────────────────────────────────────────────────────
function applyFilters() {
    const city = document.getElementById('filterCity').value.trim().toLowerCase();
    const capacity = document.querySelector('input[name=capacity]:checked')?.value || '';
    const filtered = allCars.filter(({ car }) => {
        if (city && !(car.city || '').toLowerCase().includes(city)) return false;
        if (capacity && String(car.capacity) !== capacity) return false;
        return true;
    });
    renderCards(filtered);
}
document.getElementById('filterBtn').addEventListener('click', applyFilters);

// ── City dropdown ─────────────────────────────────────────────────────────────
async function buildCityDropdown() {
    const input = document.getElementById('filterCity');
    const dropdown = document.getElementById('cityDropdown');
    try {
        const res = await fetch('https://rentcar.stepprojects.ge/api/Car/cities');
        const cities = await res.json();
        const cleanCities = cities
            .filter(c => c && c.length > 2 && /[a-zA-Z\u10D0-\u10FF]/.test(c))
            .sort();
        const allLi = document.createElement('li');
        allLi.textContent = 'ყველა';
        allLi.classList.add('selected');
        allLi.addEventListener('click', () => {
            input.value = '';
            dropdown.classList.remove('open');
            dropdown.querySelectorAll('li').forEach(l => l.classList.remove('selected'));
            allLi.classList.add('selected');
        });
        dropdown.appendChild(allLi);
        cleanCities.forEach(city => {
            const li = document.createElement('li');
            li.textContent = city;
            li.addEventListener('click', () => {
                input.value = city;
                dropdown.classList.remove('open');
                dropdown.querySelectorAll('li').forEach(l => l.classList.remove('selected'));
                li.classList.add('selected');
            });
            dropdown.appendChild(li);
        });
    } catch (err) {
        console.error('Cities fetch failed:', err);
    }
    input.addEventListener('click', () => dropdown.classList.toggle('open'));
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.city-dropdown-wrap')) dropdown.classList.remove('open');
    });
}

// ── Fetch all cars ────────────────────────────────────────────────────────────
async function fetchCars() {
    carsGrid.innerHTML = '<p class="empty-msg">იტვირთება...</p>';
    try {
        const response = await fetch('https://rentcar.stepprojects.ge/api/Car');
        if (!response.ok) throw new Error('HTTP error: ' + response.status);
        const cars = await response.json();
        const validCars = cars.filter(car => car.brand && car.model && car.price);
        allCars = await Promise.all(
            validCars.map(async car => ({ car, images: await getValidImages(car) }))
        );
        renderCards(allCars);
    } catch (err) {
        carsGrid.innerHTML = '<p class="empty-msg">შეცდომა: ' + err.message + '</p>';
    }
}

fetchCars();
buildCityDropdown();