// ── Theme ──────────────────────────────────────────────────────────────────
const theme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', theme);

// ── Auth check ─────────────────────────────────────────────────────────────
const phone = localStorage.getItem('userPhone');
if (!phone) { window.location.href = 'login.html'; }

const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
document.getElementById('loggedIn').style.display = isLoggedIn ? 'flex' : 'none';
document.getElementById('loggedOut').style.display = isLoggedIn ? 'none' : 'flex';

document.getElementById('logoutBtn')?.addEventListener('click', () => {
    ['isLoggedIn','userPhone','token'].forEach(k => localStorage.removeItem(k));
    window.location.href = 'index.html';
});

// ── Theme buttons ──────────────────────────────────────────────────────────
function applyThemeLabel(t) {
    const label = t === 'dark' ? '☀️ თემა' : '🌙 თემა';
    ['themeBtn','themeBtnIn'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = label;
    });
}
applyThemeLabel(theme);
['themeBtn','themeBtnIn'].forEach(id => {
    document.getElementById(id)?.addEventListener('click', () => {
        const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
        applyThemeLabel(next);
    });
});

// ── Populate brand dropdown from API ───────────────────────────────────────
async function loadBrands() {
    try {
        const res = await fetch('https://rentcar.stepprojects.ge/api/Car');
        const cars = await res.json();
        const brands = [...new Set(cars.map(c => c.brand).filter(Boolean))].sort();
        const sel = document.getElementById('brandSelect');
        brands.forEach(b => {
            const opt = document.createElement('option');
            opt.value = b; opt.textContent = b;
            sel.appendChild(opt);
        });
    } catch {}
}
loadBrands();

// ── Populate year dropdown ─────────────────────────────────────────────────
const yearSel = document.getElementById('yearSelect');
const currentYear = new Date().getFullYear();
for (let y = currentYear; y >= 1970; y--) {
    const opt = document.createElement('option');
    opt.value = y; opt.textContent = y;
    yearSel.appendChild(opt);
}

// ── File preview ───────────────────────────────────────────────────────────
function setupFilePreview(inputId, nameId, prevId) {
    document.getElementById(inputId).addEventListener('change', function() {
        const file = this.files[0];
        const nameEl = document.getElementById(nameId);
        const prevEl = document.getElementById(prevId);
        if (file) {
            nameEl.textContent = file.name;
            const reader = new FileReader();
            reader.onload = e => {
                prevEl.src = e.target.result;
                prevEl.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            nameEl.textContent = 'No file chosen';
            prevEl.style.display = 'none';
        }
    });
}
setupFilePreview('img1', 'name1', 'prev1');
setupFilePreview('img2', 'name2', 'prev2');
setupFilePreview('img3', 'name3', 'prev3');

// ── Submit ─────────────────────────────────────────────────────────────────
document.getElementById('submitBtn').addEventListener('click', async () => {
    const brand        = document.getElementById('brandSelect').value.trim();
    const model        = document.getElementById('modelInput').value.trim();
    const year         = document.getElementById('yearSelect').value;
    const price        = document.getElementById('priceInput').value.trim();
    const capacity     = document.getElementById('capacityInput').value.trim();
    const transmission = document.getElementById('transmissionSelect').value;
    const fuel         = document.getElementById('fuelInput').value.trim();
    const city         = document.getElementById('cityInput').value.trim();
    const img1         = document.getElementById('img1').files[0];
    const img2         = document.getElementById('img2').files[0];
    const img3         = document.getElementById('img3').files[0];
    const errorEl      = document.getElementById('errorMsg');

    // Validate
    if (!brand || !model || !year || !price || !capacity || !transmission || !city) {
        errorEl.textContent = 'გთხოვთ შეავსოთ ყველა სავალდებულო ველი';
        errorEl.style.display = 'block';
        return;
    }
    errorEl.style.display = 'none';

    const btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.textContent = 'მიმდინარეობს...';

    const formData = new FormData();
    formData.append('Brand', brand);
    formData.append('Model', model);
    formData.append('Year', parseInt(year));
    formData.append('Price', parseFloat(price));
    formData.append('Capacity', parseInt(capacity));
    formData.append('Transmission', transmission);
    formData.append('FuelCapacity', parseInt(fuel) || 0);
    formData.append('City', city);
    formData.append('CreatedBy', phone);
    formData.append('OwnerPhoneNumber', phone);
    if (img1) formData.append('Image1', img1);
    if (img2) formData.append('Image2', img2);
    if (img3) formData.append('Image3', img3);

    try {
        const res = await fetch('https://rentcar.stepprojects.ge/api/Car', {
            method: 'POST',
            body: formData
        });

        if (res.ok) {
            window.location.href = 'index.html';
        } else {
            const text = await res.text();
            errorEl.textContent = 'შეცდომა: ' + (text || res.status);
            errorEl.style.display = 'block';
            btn.disabled = false;
            btn.textContent = 'შენახვა';
        }
    } catch(err) {
        errorEl.textContent = 'შეცდომა: ' + err.message;
        errorEl.style.display = 'block';
        btn.disabled = false;
        btn.textContent = 'შენახვა';
    }
});
