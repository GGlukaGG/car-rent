// ── Theme ──────────────────────────────────────────────────────────────────
const theme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', theme);

// ── Header ─────────────────────────────────────────────────────────────────
const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
document.getElementById('loggedIn').style.display = isLoggedIn ? 'flex' : 'none';
document.getElementById('loggedOut').style.display = isLoggedIn ? 'none' : 'flex';
document.getElementById('logoutBtn')?.addEventListener('click', () => {
    ['isLoggedIn','userPhone','token'].forEach(k => localStorage.removeItem(k));
    window.location.href = 'index.html';
});

// Theme buttons
const savedTheme = localStorage.getItem('theme') || 'light';
function applyThemeLabel(t) {
    const label = t === 'dark' ? '☀️ თემა' : '🌙 თემა';
    ['themeBtn','themeBtnIn'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = label;
    });
}
applyThemeLabel(savedTheme);
['themeBtn','themeBtnIn'].forEach(id => {
    document.getElementById(id)?.addEventListener('click', () => {
        const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
        applyThemeLabel(next);
    });
});

// ── Get car ID from URL ─────────────────────────────────────────────────────
const params = new URLSearchParams(window.location.search);
const carId = params.get('id');
if (!carId) window.location.href = 'cars.html';

const BASE = 'https://rentcar.stepprojects.ge';
let carData = null;
let map = null;

// ── Load car ────────────────────────────────────────────────────────────────
async function loadCar() {
    try {
        const res = await fetch(BASE + '/api/Car/' + carId);
        if (!res.ok) throw new Error('Car not found');
        carData = await res.json();
        renderCar(carData);
        initMap(carData.city || '');
    } catch(err) {
        document.querySelector('.rent-page').innerHTML = '<p class="page-msg">მანქანა ვერ მოიძებნა</p>';
    }
}

// ── Render car details ──────────────────────────────────────────────────────
function renderCar(car) {
    document.title = 'Morent - ' + car.brand + ' ' + car.model;
    document.getElementById('carBrand').textContent = car.brand || '';
    document.getElementById('carModel').textContent = car.model || '';
    document.getElementById('carYear').textContent = car.year || '-';
    document.getElementById('carFuel').textContent = car.fuelCapacity ? car.fuelCapacity + ' ლიტრი' : '-';
    document.getElementById('carTransmission').textContent = car.transmission || '-';
    document.getElementById('carCapacity').textContent = car.capacity ? car.capacity + ' კაცი' : '-';

    // Images
    const allImgs = [car.imageUrl1, car.imageUrl2, car.imageUrl3, car.image1, car.image2, car.image3]
        .filter(u => u && u.trim() !== '');

    const mainImg = document.getElementById('mainImage');
    if (allImgs.length > 0) {
        mainImg.src = allImgs[0];
        mainImg.onerror = () => mainImg.style.display = 'none';
    } else {
        mainImg.style.display = 'none';
    }

    // Thumbnails (remaining images)
    const thumbsWrap = document.getElementById('thumbnails');
    allImgs.forEach((src, i) => {
        const div = document.createElement('div');
        div.className = 'thumb' + (i === 0 ? ' active' : '');
        const img = document.createElement('img');
        img.src = src;
        img.alt = '';
        img.onerror = () => div.style.display = 'none';
        div.appendChild(img);
        div.addEventListener('click', () => {
            mainImg.src = src;
            document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
            div.classList.add('active');
        });
        thumbsWrap.appendChild(div);
    });

    // Slider
    updatePrice();
    document.getElementById('daysSlider').addEventListener('input', updatePrice);
}

// ── Price calculation ───────────────────────────────────────────────────────
function updatePrice() {
    if (!carData) return;
    const days = parseInt(document.getElementById('daysSlider').value);
    const price = carData.price || 0;
    const total = price * days;
    document.getElementById('daysLabel').textContent = days + ' დღე';
    document.getElementById('totalPrice').textContent = total + '₾';
    document.getElementById('priceDisplay').innerHTML = total + '₾';
}

// ── Map ─────────────────────────────────────────────────────────────────────
async function initMap(city) {
    // Geocode city using Nominatim (free, no API key)
    let lat = 41.6941; // default: Georgia center
    let lng = 44.8337;

    if (city) {
        try {
            const geo = await fetch(
                'https://nominatim.openstreetmap.org/search?q=' +
                encodeURIComponent(city + ', Georgia') +
                '&format=json&limit=1'
            );
            const results = await geo.json();
            if (results && results.length > 0) {
                lat = parseFloat(results[0].lat);
                lng = parseFloat(results[0].lon);
            }
        } catch {}
    }

    map = L.map('map').setView([lat, lng], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap'
    }).addTo(map);

    // Custom marker popup
    const popupHtml = `
        <div style="min-width:160px">
            <strong>${carData.brand} ${carData.model}</strong><br>
            <span style="color:#888;font-size:0.85rem">${city || ''}</span>
        </div>
    `;
    L.marker([lat, lng]).addTo(map).bindPopup(popupHtml).openPopup();
}

// ── Buy / Rent ──────────────────────────────────────────────────────────────
document.getElementById('buyBtn').addEventListener('click', async () => {
    const phone = localStorage.getItem('userPhone');
    if (!phone) {
        alert('გთხოვთ შეხვიდეთ სისტემაში');
        window.location.href = 'login.html';
        return;
    }

    const days = parseInt(document.getElementById('daysSlider').value);
    const btn = document.getElementById('buyBtn');
    btn.disabled = true;
    btn.textContent = 'მიმდინარეობს...';

    try {
        const res = await fetch(
            BASE + '/Purchase/purchase?phoneNumber=' + encodeURIComponent(phone) +
            '&carId=' + carId +
            '&multiplier=' + days,
            { method: 'POST', headers: { 'Content-Type': 'application/json' } }
        );

        if (res.ok) {
            const total = (carData.price || 0) * days;
            
            document.getElementById('successScreen').style.display = 'flex';
        } else {
            const text = await res.text();
            alert('შეცდომა: ' + (text || res.status));
            btn.disabled = false;
            btn.textContent = 'ყიდვა';
        }
    } catch(err) {
        alert('შეცდომა: ' + err.message);
        btn.disabled = false;
        btn.textContent = 'ყიდვა';
    }
});

loadCar();
